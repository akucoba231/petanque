let segment1 = [
  {
    "id": 1,
    "model": "MODEL LATIHAN I",
    "nama": "DRILL POINT-SHOOT TRANSITION",
    "tujuan_utama": "Melatih Transisi tantara teknik pointing dan shooting",
    "gambar": "1.png",
    "video": "https://drive.google.com/file/d/1rE6fGASt4OX-qXQR_74rjcLZbeXH2gk8/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik pointing.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "lemparan pointing dengan posisi jongkok fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam Lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan shooting .",
        "coaching_point": "Menembak Bosi sasaran agar keluar lingkaran.",
        "target": "Hasil lemparan harus mengenai bosi sasaran yang ada di lingkaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle."
      }
    ]
  },
  {
    "id": 2,
    "model": "MODEL LATIHAN 2",
    "nama": "DRILL TACTICAL POINTING - SHOOTING",
    "tujuan_utama": "Melatih lemparan Pointing dan shooting untuk mendapatkan poin.",
    "gambar": "2.png",
    "video": "https://drive.google.com/file/d/1em5MASCbbAkGGEkowOzl7z18Fvt4PU0K/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 1 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle/sasaran dengan jarak = 50cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam Lingkaran / circle, dan harus lebih dekat ke boka daripada bosi sasaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi sasaran.",
        "target": "Hasil lemparan harus mengenai bosi sasaran yang ada di lingkaran dan tidak merubah posisi boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "mendapatkan point (Bosi harus masuk ke dalam lingkaran / Circle)."
      }
    ]
  },
  {
    "id": 3,
    "model": "MODEL LATIHAN 3",
    "nama": "DRILL  SHOOTING – POINTING Recovery",
    "tujuan_utama": "Melatih lemparan shooting untuk mengeluarkan bosi sasaran dan mendapatkan poin.",
    "gambar": "3.png",
    "video": "https://drive.google.com/file/d/1MkliBQ-JTUErpewaavfzn5PrnuOHKjWv/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 1 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle/sasaran dengan jarak = 35cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi sasaran dan bosi hasil lemparan tidak keluar dari lingkaran.",
        "target": "mengeluarkan Bosi sasaran dan menempatkan bosi di dalam area lingkaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Pointing.",
        "tujuan": "Meningkatkan akurasi lemparan Pointingˆ..",
        "coaching_point": ": Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle untuk menambah poin."
      }
    ]
  }
]

let segment2 = [
  {
    "id": 4,
    "model": "MODEL LATIHAN 4 - (SITUASI - 1)",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "gambar": "4.png",
    "video": "https://drive.google.com/file/d/1rNwrjCoORqpOqdEF08zlCPaCjT6PiLtq/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi : sejajar dengan boka.",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi : Sejajar dengan boka di sebelah kanan boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menentukan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat dibandingkan bosi obstacle 1.",
        "target": "menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu memperbesar keunggulan poin yang di peroleh."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu memperbesar keunggulan poin yang di peroleh."
      }
    ]
  },
  {
    "id": 5,
    "model": "MODEL LATIHAN 4 - (SITUASI - 2)",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "gambar": "4.png",
    "video": "https://drive.google.com/file/d/1rNwrjCoORqpOqdEF08zlCPaCjT6PiLtq/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 15 cm dari boka. Posisi : sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 40cm dari boka. Posisi : Sejajar dengan boka di sebelah kiri boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle paling dekat ke boka untuk mendapatkan poin.",
        "target": "mengeluarkan bosi obstacle paling dekat dari boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle 2 untuk menjauh dari boka.",
        "target": "Atlet mampu memperbesar peluang poin yang di peroleh."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Atlet mampu menempatkan bosi ke dalam lingkaran dekat dengan boka.",
        "target": "Mendekatkan bosi ke boka."
      }
    ]
  },
  {
    "id": 6,
    "model": "MODEL LATIHAN 4 - (SITUASI - 3)",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "gambar": "4.png",
    "video": "https://drive.google.com/file/d/1rNwrjCoORqpOqdEF08zlCPaCjT6PiLtq/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50 cm dari boka. Posisi : sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi : Sejajar dengan boka di sebelah kiri boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mengambil keputusan mendekatkan bosi ke boka tanpa menghiraukan bosi obstacle untuk mendapatkan poin.",
        "target": "mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mengambil keputusan mendekatkan bosi ke boka tanpa menghiraukan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu menguasai lemparan."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Atlet mampu menempatkan bosi ke dalam lingkaran dekat dengan boka.",
        "target": "Mendekatkan bosi ke boka."
      }
    ]
  }
]

let segment3 = [
  {
    "id": 7,
    "model": "MODEL LATIHAN 5",
    "nama": "DRILL BLOCKING POINTING - SHOOTING",
    "tujuan_utama": "Melatih Keterampilan Penempatan Bosi",
    "gambar": "5.png",
    "video": "https://drive.google.com/file/d/1PK0SxzsEy2vRX2RiJVqdRdcCloFNVT0R/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 2 set (6 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi untuk lemparan Pointing.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menyiapkan 3 bosi untuk lemparan Shooting.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1-3 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka..",
        "target": "Menempatkan bosi sejajar untuk menghalangi boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-4-6 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting..",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi menghalangi boka.",
        "target": "menembak bosi tanpa mengeluarkan boka dari lingkaran."
      }
    ]
  }
]

let segment4 = [
  {
    "id": 8,
    "model": "MODEL LATIHAN 6 - (Jarak 6 Meter – 8 Meter)",
    "nama": "DRILL DISTANCE COMBINATION TRAINING",
    "tujuan_utama": "MELATIH KOMBINASI TEKNIK LEMPARAN PADA BERBAGAI JARAK",
    "gambar": "6.png",
    "video": "https://drive.google.com/file/d/1lYW4DszI1518vFzjeLPSyxRXSMTduW-D/view",
    "perlengkapan": [
      "Atlet berjumlah 2 orang",
      "Atlet 1 =Pointer",
      "Atlet 2 =Shooter",
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 2 set (6 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6,7,dan 8 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "- Atlet 1 (Pointer) menyiapkan 3 bosi dan focus untuk melakukan lemparan Pointing. - Atlet 2 (Shooter) meenyiapkan 3 bosi dan focus untuk melakukan lemparan Shooting. - Kedua atlet ini akan saling bergantian disesuaikan oleh pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-1 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-2 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-2 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-3 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-3 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      }
    ]
  },
  {
    "id": 9,
    "model": "MODEL LATIHAN 6 - (Jarak 9 Meter)",
    "nama": "DRILL DISTANCE COMBINATION TRAINING",
    "tujuan_utama": "MELATIH KOMBINASI TEKNIK LEMPARAN PADA BERBAGAI JARAK",
    "gambar": "6.png",
    "video": "https://drive.google.com/file/d/1lYW4DszI1518vFzjeLPSyxRXSMTduW-D/view",
    "perlengkapan": [
      "Atlet berjumlah 2 orang",
      "Atlet 1 =Pointer",
      "Atlet 2 =Shooter",
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 2 set (6 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 2 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 9 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "- Atlet 1 (Pointer) menyiapkan 3 bosi dan focus untuk melakukan lemparan Pointing. - Atlet 2 (Shooter) meenyiapkan 3 bosi dan focus untuk melakukan lemparan Shooting. - Kedua atlet ini akan saling bergantian disesuaikan oleh pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi berdiri,hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka"
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-1 menggunakan teknik Shooting, hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva focus untuk mengeluarkan bosi dari lingkaran.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-2 menggunakan teknik Pointing dengan posisi berdiri,hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-2 menggunakan teknik Shooting, hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva focus untuk mengeluarkan bosi dari lingkaran.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi berdiri,hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-3 menggunakan teknik Shooting, hasil lemparan berbentuk lengkungan melewati media lempar gawang atau kurva focus untuk mengeluarkan bosi dari lingkaran.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/Circle."
      }
    ]
  }
]

let segment5 = [
  {
    "id": 10,
    "model": "MODEL LATIHAN 7 - (Jarak 6m Situasi - 1)",
    "nama": "DRILL PRESSURE SITUATION TRAINING",
    "tujuan_utama": "MELATIH TEKNIK LEMPARAN DENGAN TEKANAN (OBSTACLE)",
    "gambar": "7.png",
    "video": "https://drive.google.com/file/d/1DbrHXwU61w9kfxOEb7AdVj3EeFDgIhqL/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 45cm dari boka. Posisi : sejajar dengan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 45cm dari boka. Posisi : Sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 45cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat ke boka.",
        "target": "menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 11,
    "model": "MODEL LATIHAN 7 - (Jarak 7m Situasi - 2)",
    "nama": "DRILL PRESSURE SITUATION TRAINING",
    "tujuan_utama": "MELATIH TEKNIK LEMPARAN DENGAN TEKANAN (OBSTACLE)",
    "gambar": "7.png",
    "video": "https://drive.google.com/file/d/1DbrHXwU61w9kfxOEb7AdVj3EeFDgIhqL/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 7 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 20 cm dari boka. Posisi : di depan, sejajar dengan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 20 cm dari boka. Posisi : Sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 45 cm dari boka. Posisi : sejajar dengan boka di sebelah kiri boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Shooting dengan, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mengeluarkan bosi obstacle dari luar lingkaran.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu mengeluarkan bosi obstacle keluar dari lingkaran.",
        "target": "mengeluarkan bosi yang menutupi boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting dengan, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mengeluarkan bosi obstacle dari luar lingkaran.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu mengeluarkan bosi obstacle keluar dari lingkaran.",
        "target": "Mengeluarkan bosi Obstacle dari lingkaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi obstacle ke-3.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 12,
    "model": "MODEL LATIHAN 7 - (Jarak 8m Situasi - 4)",
    "nama": "DRILL PRESSURE SITUATION TRAINING",
    "tujuan_utama": "MELATIH TEKNIK LEMPARAN DENGAN TEKANAN (OBSTACLE)",
    "gambar": "7.png",
    "video": "https://drive.google.com/file/d/1DbrHXwU61w9kfxOEb7AdVj3EeFDgIhqL/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 9 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 20 cm dari boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 20 cm dari boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 20 cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan boka, memanfaatkan ruang kosong.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu memanfaatkan ruang kosong dekat boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Pointing dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan boka, memanfaatkan ruang kosong..",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi Obstacle.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan boka, memanfaatkan ruang kosong.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi Obstacle.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 13,
    "model": "MODEL LATIHAN 7 - (Jarak 9m Situasi - 4)",
    "nama": "DRILL PRESSURE SITUATION TRAINING",
    "tujuan_utama": "MELATIH TEKNIK LEMPARAN DENGAN TEKANAN (OBSTACLE)",
    "gambar": "7.png",
    "video": "https://drive.google.com/file/d/1DbrHXwU61w9kfxOEb7AdVj3EeFDgIhqL/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 2 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 20 cm dari boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 40 cm dari boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 40 cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Shooting dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi obstacle 1 yang paling dekat dengan boka.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet melakukan lemparan Shooting untuk mengeluarkan bosi obstacle paling dekat dari boka.",
        "target": "mengeluarkan bosi obstacledari lingkaran dan menjauhkan dari boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Pointing dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan boka, memanfaatkan ruang kosong..",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi Obstacle.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan boka, memanfaatkan ruang kosong.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi Obstacle.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  }
]

let segment6 = [
  {
    "id": 14,
    "model": "MODEL LATIHAN 8 - (Jarak 6meter)",
    "nama": "DRILL ALTERNATING TRAINING",
    "tujuan_utama": "MELATIH RITME TEKNIK LEMPARAN",
    "gambar": "8.png",
    "video": "https://drive.google.com/file/d/19d9L_xNtW__dLv_cyLWBVrFFpIiXF029/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Mampu mengatur lemparan untuk mendekatkan bosi ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi hasil lemparan ke-1.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengeluarkan bosi hasil lemparan ke-1.",
        "target": "mengatur lemparan Shooting."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi hasil lemparan ke-2.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 15,
    "model": "MODEL LATIHAN 8 - (Jarak 7meter)",
    "nama": "DRILL ALTERNATING TRAINING",
    "tujuan_utama": "MELATIH RITME TEKNIK LEMPARAN",
    "gambar": "8.png",
    "video": "https://drive.google.com/file/d/19d9L_xNtW__dLv_cyLWBVrFFpIiXF029/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 7 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Mampu mengatur lemparan untuk mendekatkan bosi ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi hasil lemparan ke-1.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengeluarkan bosi hasil lemparan ke-1.",
        "target": "mengatur lemparan Shooting."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi hasil lemparan ke-2.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 16,
    "model": "MODEL LATIHAN 8 - (Jarak 8meter)",
    "nama": "DRILL ALTERNATING TRAINING",
    "tujuan_utama": "MELATIH RITME TEKNIK LEMPARAN",
    "gambar": "8.png",
    "video": "https://drive.google.com/file/d/19d9L_xNtW__dLv_cyLWBVrFFpIiXF029/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 8 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Mampu mengatur lemparan untuk mendekatkan bosi ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi hasil lemparan ke-1.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengeluarkan bosi hasil lemparan ke-1.",
        "target": "mengatur lemparan Shooting."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi hasil lemparan ke-2.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  },
  {
    "id": 17,
    "model": "MODEL LATIHAN 8 - (Jarak 9meter)",
    "nama": "DRILL ALTERNATING TRAINING",
    "tujuan_utama": "MELATIH RITME TEKNIK LEMPARAN",
    "gambar": "8.png",
    "video": "https://drive.google.com/file/d/19d9L_xNtW__dLv_cyLWBVrFFpIiXF029/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 9 meter.",
      "Simpan circle2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi berdiri, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Mampu mengatur lemparan untuk mendekatkan bosi ke boka.",
        "target": "Menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting dengan hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi hasil lemparan ke-1.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengeluarkan bosi hasil lemparan ke-1.",
        "target": "mengatur lemparan Shooting."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik Pointing dengan posisi berdiri,hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menempatkan bosi lebih dekat ke boka, memanfaatkan ruang terbuka, tanpa menghiraukan bosi hasil lemparan ke-2.",
        "target": "Menempatkan bosi di area yang kosong."
      }
    ]
  }
]

let segment7 = [
  {
    "id": 18,
    "model": "MODEL LATIHAN 9 - (Situasi 1 (6-7m))",
    "nama": "DRILL TARGET ZONA TRAINING",
    "tujuan_utama": "MELATIH PRESISI LEMPARAN SESUAI ARAH TARGET",
    "gambar": "9.png",
    "video": "https://drive.google.com/file/d/1paox5yu-kZ-YtG9TlluzUoxP75YDk3Kr/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 4 buah",
      "Corong/cones= 3 buah",
      "Bosi = 2 set (6 buah)"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 6 meter, letakan di sebelah kiri dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 6 meter, letakan di sebelah kanan dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 7 meter, letakan lurus sejajar dengan posisi circle lempar."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 6 bosi. 3 Bosi pertama digunakan untuk lemparan Pointing. 3 Bosi kedua digunakan untuk lemparan Shooting.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-4 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-1. Atlet melakukan lemparan ke-5 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-2. Atlet melakukan lemparan ke-6 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-3.",
        "tujuan": "Melatih akurasi lemparan Shooting dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan Shooting sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan."
      }
    ]
  },
  {
    "id": 19,
    "model": "MODEL LATIHAN 9 - (Situasi 2 (7-8m))",
    "nama": "DRILL TARGET ZONA TRAINING",
    "tujuan_utama": "MELATIH PRESISI LEMPARAN SESUAI ARAH TARGET",
    "gambar": "9.png",
    "video": "https://drive.google.com/file/d/1paox5yu-kZ-YtG9TlluzUoxP75YDk3Kr/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 4 buah",
      "Corong/cones= 3 buah",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter",
      "Bosi = 2 set (6 buah)"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 7 meter, letakan di sebelah kiri dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 7 meter, letakan di sebelah kanan dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 8 meter, letakan lurus sejajar dengan posisi circle lempar."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 6 bosi. 3 Bosi pertama digunakan untuk lemparan Pointing. 3 Bosi kedua digunakan untuk lemparan Shooting.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-4 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-1. Atlet melakukan lemparan ke-5 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-2. Atlet melakukan lemparan ke-6 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-3.",
        "tujuan": "Melatih akurasi lemparan Shooting dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan Shooting sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan."
      }
    ]
  },
  {
    "id": 20,
    "model": "MODEL LATIHAN 9 - (Situasi 3 (8-9m))",
    "nama": "DRILL TARGET ZONA TRAINING",
    "tujuan_utama": "MELATIH PRESISI LEMPARAN SESUAI ARAH TARGET",
    "gambar": "9.png",
    "video": "https://drive.google.com/file/d/1paox5yu-kZ-YtG9TlluzUoxP75YDk3Kr/view",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 4 buah",
      "Corong/cones= 3 buah",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter",
      "Bosi = 2 set (6 buah)"
    ],
    "layout_latihan": [
      "Simpan Circle1 di posisi atlet melempar.",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 8 meter, letakan di sebelah kiri dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 8 meter, letakan di sebelah kanan dari posisi circle lempar (posisi menyerong).",
      "Simpan cones di Tengah-tengah lingkaran/circle (diameter 50cm) dengan jarak 9 meter, letakan lurus sejajar dengan posisi circle lempar."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 6 bosi. 3 Bosi pertama digunakan untuk lemparan Pointing. 3 Bosi kedua digunakan untuk lemparan Shooting.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 sesuai target dan arah yang sudah di tentukan, dengan teknik lemparan Pointing dengan posisi berdiri, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan target dan arah yang sudah ditentukan.",
        "tujuan": "Melatih akurasi lemparan Pointing dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan pointing sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan, dan menempatkan bosi di dalam lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-4 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-1. Atlet melakukan lemparan ke-5 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-2. Atlet melakukan lemparan ke-6 dengan melakukan lemparan Shooting untuk mengeluarkan bosi yang ada di dalam lingkaran hasil lemparan ke-3.",
        "tujuan": "Melatih akurasi lemparan Shooting dengan arah dan target.",
        "coaching_point": "atlet melakukan lemparan Shooting sesuai target dan arah yang sudah ditentukan serta menempatkan bosi sesuai target.",
        "target": "Lemparan yang dihasilkan sesuai target dan arah yang ditentukan."
      }
    ]
  }
]

let segment8 = [
  {
    "id": 21,
    "model": "MODEL LATIHAN 10 - (Jarak 6 m)",
    "nama": "DRILL GAME SIMULATION",
    "tujuan_utama": "MENSIMULASIKAN KONDISI PERTANDINGAN SEBENARNYA",
    "gambar": "",
    "video": "",
    "perlengkapan": [
      "Boka = 1 buah",
      "Bosi = disesuaikan dengan nomor pertandingan",
      "Circle = 1"
    ],
    "layout_latihan": [
      "Lapangan Petanque sesuai aturan resmi.",
      "Sesuaikan atlet dengan nomor pertandingan yang di simulasikan (Single, double / triple)"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Diawali dengan lemparan boka (Jack) oleh atlet, seusaikan jarak dengan intruksi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan pengecekan terhadap situasi lapangan, dropma dan posisi bosi yang akan di tuju.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan pertama dengan teknik Pointing posisi jongkok hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan dropma arah yang sudah ditentukan.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Pelatih membuat skenario posisi bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menentukan strategi, dengan melakukan pengecekan terhadap skenario posisi bosi yang diberikan pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan lanjutan dengan memilih Pointing atau shooting.",
        "tujuan": "mengintegrasikan teknik dan penentuan Keputusan dalam pertandingan.",
        "coaching_point": "atlet mampu mengatasi skenario posisi bola yang diberikan pelatih.",
        "target": "atlet mampu menciptakan point sebanyak mungkin dalam artian bosi atlet mampu mendekati boka (Jack) sebanyak mungkin."
      }
    ]
  },
  {
    "id": 22,
    "model": "MODEL LATIHAN 10 - (Jarak 7 m)",
    "nama": "DRILL GAME SIMULATION",
    "tujuan_utama": "MENSIMULASIKAN KONDISI PERTANDINGAN SEBENARNYA",
    "gambar": "",
    "video": "",
    "perlengkapan": [
      "Boka = 1 buah",
      "Bosi = disesuaikan dengan nomor pertandingan",
      "Circle = 1"
    ],
    "layout_latihan": [
      "Lapangan Petanque sesuai aturan resmi.",
      "Sesuaikan atlet dengan nomor pertandingan yang di simulasikan (Single, double / triple)"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Diawali dengan lemparan boka (Jack) oleh atlet, seusaikan jarak dengan intruksi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan pengecekan terhadap situasi lapangan, dropma dan posisi bosi yang akan di tuju.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan pertama dengan teknik Pointing hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan dropma arah yang sudah ditentukan.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Pelatih membuat skenario posisi bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menentukan strategi, dengan melakukan pengecekan terhadap skenario posisi bosi yang diberikan pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan lanjutan dengan memilih Pointing atau shooting.",
        "tujuan": "mengintegrasikan teknik dan penentuan Keputusan dalam pertandingan.",
        "coaching_point": "atlet mampu mengatasi skenario posisi bola yang diberikan pelatih.",
        "target": "atlet mampu menciptakan point sebanyak mungkin dalam artian bosi atlet mampu mendekati boka (Jack) sebanyak mungkin."
      }
    ]
  },
  {
    "id": 23,
    "model": "MODEL LATIHAN 10 - (Jarak 8 m)",
    "nama": "DRILL GAME SIMULATION",
    "tujuan_utama": "MENSIMULASIKAN KONDISI PERTANDINGAN SEBENARNYA",
    "gambar": "",
    "video": "",
    "perlengkapan": [
      "Boka = 1 buah",
      "Bosi = disesuaikan dengan nomor pertandingan",
      "Circle = 1"
    ],
    "layout_latihan": [
      "Lapangan Petanque sesuai aturan resmi.",
      "Sesuaikan atlet dengan nomor pertandingan yang di simulasikan (Single, double / triple)"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Diawali dengan lemparan boka (Jack) oleh atlet, seusaikan jarak dengan intruksi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan pengecekan terhadap situasi lapangan, dropma dan posisi bosi yang akan di tuju.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan pertama dengan teknik Pointing hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan dropma arah yang sudah ditentukan.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Pelatih membuat skenario posisi bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menentukan strategi, dengan melakukan pengecekan terhadap skenario posisi bosi yang diberikan pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan lanjutan dengan memilih Pointing atau shooting.",
        "tujuan": "mengintegrasikan teknik dan penentuan Keputusan dalam pertandingan.",
        "coaching_point": "atlet mampu mengatasi skenario posisi bola yang diberikan pelatih.",
        "target": "atlet mampu menciptakan point sebanyak mungkin dalam artian bosi atlet mampu mendekati boka (Jack) sebanyak mungkin."
      }
    ]
  },
  {
    "id": 24,
    "model": "MODEL LATIHAN 10 - (Jarak 9 m)",
    "nama": "DRILL GAME SIMULATION",
    "tujuan_utama": "MENSIMULASIKAN KONDISI PERTANDINGAN SEBENARNYA",
    "gambar": "",
    "video": "",
    "perlengkapan": [
      "Boka = 1 buah",
      "Bosi = disesuaikan dengan nomor pertandingan",
      "Circle = 1"
    ],
    "layout_latihan": [
      "Lapangan Petanque sesuai aturan resmi.",
      "Sesuaikan atlet dengan nomor pertandingan yang di simulasikan (Single, double / triple)"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Diawali dengan lemparan boka (Jack) oleh atlet, seusaikan jarak dengan intruksi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan pengecekan terhadap situasi lapangan, dropma dan posisi bosi yang akan di tuju.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan pertama dengan teknik Pointing hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan dropma arah yang sudah ditentukan.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Pelatih membuat skenario posisi bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menentukan strategi, dengan melakukan pengecekan terhadap skenario posisi bosi yang diberikan pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan lanjutan dengan memilih Pointing atau shooting.",
        "tujuan": "mengintegrasikan teknik dan penentuan Keputusan dalam pertandingan.",
        "coaching_point": "atlet mampu mengatasi skenario posisi bola yang diberikan pelatih.",
        "target": "atlet mampu menciptakan point sebanyak mungkin dalam artian bosi atlet mampu mendekati boka (Jack) sebanyak mungkin."
      }
    ]
  }
];

segment8.forEach(item => {
  item.gambar = "10.png";
  item.video = "https://drive.google.com/file/d/1nsArO79GaHog7AY2AanjJE9kIqFpNlQ5/view";
})

console.log(segment8)

let dataModelLatihan = [...segment1, ...segment2, ...segment3, ...segment4, ...segment5, ...segment6, ...segment7, ...segment8];