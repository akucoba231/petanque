let dataLatihan = [
  {
    "id": 1,
    "model": "MODEL LATIHAN I",
    "nama": "DRILL POINT-SHOOT TRANSITION",
    "tujuan_utama": "Melatih Transisi antara teknik pointing dan shooting",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Boka = 1"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka"
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik pointing.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "lemparan pointing dengan posisi jongkok fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam Lingkaran / circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Menembak Bosi sasaran agar keluar lingkaran.",
        "target": "Hasil lemparan harus mengenai bosi sasaran yang ada di lingkaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle."
      }
    ]
  },
  {
    "id": 2,
    "model": "MODEL LATIHAN 2",
    "nama": "DRILL TACTICAL POINTING - SHOOTING",
    "tujuan_utama": "Melatih lemparan Pointing dan shooting untuk mendapatkan poin.",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 1 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka",
      "Simpan Bosi Obstacle/sasaran dengan jarak = 50cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam Lingkaran / circle, dan harus lebih dekat ke boka daripada bosi sasaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi sasaran.",
        "target": "Hasil lemparan harus mengenai bosi sasaran yang ada di lingkaran dan tidak merubah posisi boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "mendapatkan point (Bosi harus masuk ke dalam lingkaran / Circle)."
      }
    ]
  },
  {
    "id": 3,
    "model": "MODEL LATIHAN 3",
    "nama": "DRILL SHOOTING – POINTING Recovery",
    "tujuan_utama": "Melatih lemparan shooting untuk mengeluarkan bosi sasaran dan mendapatkan poin.",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 1 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka",
      "Simpan Bosi Obstacle/sasaran dengan jarak = 35cm dari boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi sasaran dan bosi hasil lemparan tidak keluar dari lingkaran.",
        "target": "mengeluarkan Bosi sasaran dan menempatkan bosi di dalam area lingkaran."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menggunakan teknik Pointing.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Bosi harus masuk ke dalam lingkaran / Circle untuk menambah poin."
      }
    ]
  },
  {
    "id": 4,
    "model": "MODEL LATIHAN 4 - SITUASI 1",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi: sejajar dengan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi: Sejajar dengan boka di sebelah kanan boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet menentukan posisi bosi untuk mendapatkan poin, dengan cara menempatkan bosi lebih dekat dibandingkan bosi obstacle 1.",
        "target": "menempatkan bosi di area yang kosong."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu memperbesar keunggulan poin yang di peroleh."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu memperbesar keunggulan poin yang di peroleh."
      }
    ]
  },
  {
    "id": 5,
    "model": "MODEL LATIHAN 4 - SITUASI 2",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 15 cm dari boka. Posisi: sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 40cm dari boka. Posisi: Sejajar dengan boka di sebelah kiri boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle paling dekat ke boka untuk mendapatkan poin.",
        "target": "mengeluarkan bosi obstacle paling dekat dari boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik shooting harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan shooting.",
        "coaching_point": "Atlet mengambil keputusan mengeluarkan bosi obstacle 2 untuk menjauh dari boka.",
        "target": "Atlet mampu memperbesar peluang poin yang di peroleh."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Atlet mampu menempatkan bosi ke dalam lingkaran dekat dengan boka.",
        "target": "Mendekatkan bosi ke boka."
      }
    ]
  },
  {
    "id": 6,
    "model": "MODEL LATIHAN 4 - SITUASI 3",
    "nama": "DRILL DECISION TRAINING",
    "tujuan_utama": "MELATIH PENGAMBILAN KEPUTUSAN ANTARA POINTING DAN SHOOTING",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 1 set (3 buah)",
      "Bosi (Obstacle) = 2 buah",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter.",
      "Simpan circle 2 di posisi boka",
      "Simpan Bosi Obstacle 1 / Bosi sasaran dengan jarak = 50 cm dari boka. Posisi: sejajar dengan boka di sebelah kanan boka.",
      "Simpan Bosi Obstacle 2 / Bosi sasaran dengan jarak = 50cm dari boka. Posisi: Sejajar dengan boka di sebelah kiri boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mengambil keputusan mendekatkan bosi ke boka tanpa menghiraukan bosi obstacle untuk mendapatkan poin.",
        "target": "mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-2 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mengambil keputusan mendekatkan bosi ke boka tanpa menghiraukan bosi obstacle untuk mendapatkan poin.",
        "target": "Atlet mampu menguasai lemparan."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-3 menentukan untuk menggunakan teknik Pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "tujuan": "Meningkatkan akurasi lemparan pointing.",
        "coaching_point": "Atlet mampu menempatkan bosi ke dalam lingkaran dekat dengan boka.",
        "target": "Mendekatkan bosi ke boka."
      }
    ]
  },
  {
    "id": 7,
    "model": "MODEL LATIHAN 5",
    "nama": "DRILL BLOCKING POINTING - SHOOTING",
    "tujuan_utama": "Melatih Keterampilan Penempatan Bosi",
    "perlengkapan": [
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 2 set (6 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6 meter."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet menyiapkan 3 bosi untuk lemparan Pointing.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet menyiapkan 3 bosi untuk lemparan Shooting.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-1-3 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Lemparan pointing dengan posisi jongkok, hasil lemparan berbentuk lengkungan atau kurva fokus untuk mendekatkan bosi ke boka dengan titik jatuhan bosi (dropma) disesuaikan 1-2 meter sebelum boka.",
        "target": "Menempatkan bosi sejajar untuk menghalangi boka."
      },
      {
        "deskripsi": "Atlet melakukan lemparan ke-4-6 menggunakan teknik Shooting.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Lemparan shooting, hasil lemparan berbentuk lengkungan atau kurva fokus untuk menembak bosi menghalangi boka.",
        "target": "menembak bosi tanpa mengeluarkan boka dari lingkaran."
      }
    ]
  },
  {
    "id": 8,
    "model": "MODEL LATIHAN 6 - Jarak 6 Meter – 8 Meter",
    "nama": "DRILL DISTANCE COMBINATION TRAINING",
    "tujuan_utama": "MELATIH KOMBINASI TEKNIK LEMPARAN PADA BERBAGAI JARAK",
    "perlengkapan": [
      "Atlet berjumlah 2 orang (Atlet 1 = Pointer, Atlet 2 = Shooter)",
      "Lingkaran / Circle 50 Cm = 2 buah",
      "Bosi = 2 set (6 buah)",
      "Boka = 1",
      "Media Lemparan berbentuk gawang = ukuran tinggi 1 Meter"
    ],
    "layout_latihan": [
      "Simpan Circle 1 di posisi atlet melempar.",
      "Simpan media lemparan berbentuk gawang berjarak 2 meter dari lingkaran lempar.",
      "Simpan Boka di jarak 6,7,dan 8 meter.",
      "Simpan circle 2 di posisi boka."
    ],
    "langkah_langkah": [
      {
        "deskripsi": "Atlet 1 (Pointer) menyiapkan 3 bosi dan focus untuk melakukan lemparan Pointing.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet 2 (Shooter) menyiapkan 3 bosi dan focus untuk melakukan lemparan Shooting. Kedua atlet ini akan saling bergantian disesuaikan oleh pelatih.",
        "tujuan": "",
        "coaching_point": "",
        "target": ""
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-1 menggunakan teknik Pointing dengan posisi jongkok, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-1 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/ Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-2 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-2 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/ Circle."
      },
      {
        "deskripsi": "Atlet 1 melakukan lemparan ke-3 menggunakan teknik Pointing, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Pointing.",
        "coaching_point": "Atlet mampu Menempatkan bosi sedekat mungkin ke boka.",
        "target": "Mendekatkan bosi ke boka."
      },
      {
        "deskripsi": "Atlet 2 melakukan lemparan ke-3 menggunakan teknik Shooting, harus melewati media lemparan gawang.",
        "tujuan": "Meningkatkan akurasi lemparan Shooting.",
        "coaching_point": "Atlet mampu Mengeluarkan bosi hasil dari lemparan (atlet 1).",
        "target": "Menembak bosi di dalam lingkaran/ Circle."
      }
    ]
  }
]

dataLatihan = dataLatihan.map(item => ({
  ...item,
  gambar : "",
  video : "",
}))